package com.prem.Api.ServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.prem.Api.Entity.LoginRequestBody;
import com.prem.Api.Repository.RegisterRepository;
import com.prem.Api.Service.LoginService;
@Service
public class LoginServiceImpl implements LoginService{
	@Autowired
	private RegisterRepository registerRepo;
	@Autowired
	private PasswordEncoder passwordEncoder;

	@Override
	public void RegisterUser(LoginRequestBody requestBody) {
		requestBody.setPassword(passwordEncoder.encode(requestBody.getPassword()));
		registerRepo.save(requestBody);
	}

}
