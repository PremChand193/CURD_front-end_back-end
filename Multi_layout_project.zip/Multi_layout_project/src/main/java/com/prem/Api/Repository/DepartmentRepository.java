package com.prem.Api.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prem.Api.Entity.Department;

public interface DepartmentRepository extends JpaRepository<Department, Integer> {

}
