package com.prem.Api.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prem.Api.Entity.Department;
import com.prem.Api.Entity.Employee;
import com.prem.Api.Repository.EmployeeRepository;
import com.prem.Api.Service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	private EmployeeRepository employeeRepo;

	@Override
	public void createEmployee(Employee employee) {
		employeeRepo.save(employee);
	}

	@Override
	public List<Employee> getAllEmployees() {
		List<Employee> employee=employeeRepo.findAll();
		return employee;
	}

	@Override
	public List<Employee> getAllEmployeesByDeptId(int deptId) {
		Department department = new Department();
		department.setDeptId(deptId); // Set the department ID to 3
		List<Employee> employee=employeeRepo.findByDeptIdDeptId(deptId);
		System.out.println(employee);
		return employee;
	}

}
