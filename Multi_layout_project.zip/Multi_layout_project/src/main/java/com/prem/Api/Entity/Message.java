package com.prem.Api.Entity;

import lombok.Data;

@Data
public class Message {
       private String message;

	public Message(String message) {
		super();
		this.message = message;
	}

	public Message() {
		super();
		
	}
       
}
