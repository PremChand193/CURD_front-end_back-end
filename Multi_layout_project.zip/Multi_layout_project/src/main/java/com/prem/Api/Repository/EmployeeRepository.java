package com.prem.Api.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prem.Api.Entity.Department;
import com.prem.Api.Entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	

	List<Employee> findByDeptIdDeptId(int deptId);

}
