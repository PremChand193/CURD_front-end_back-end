package com.prem.Api.Service;

import java.util.List;

import com.prem.Api.Entity.Department;
import com.prem.Api.Entity.Employee;

public interface EmployeeService {

	
	public void createEmployee(Employee employee);
	
	public List<Employee> getAllEmployees();

	public List<Employee> getAllEmployeesByDeptId(int deptId);
}
