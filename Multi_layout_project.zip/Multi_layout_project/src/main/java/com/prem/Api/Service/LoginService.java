package com.prem.Api.Service;

import com.prem.Api.Entity.LoginRequestBody;

public interface LoginService {
    public void RegisterUser(LoginRequestBody requestBody);
}
