package com.prem.Api.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.Data;
@Data
@Entity
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int empId;
    @OneToOne  
    private Department deptId;
    private String empName;
    private String empSalary;
	public Employee() {
		super();
	
	}

	public Employee(int empId, Department deptId, String empName, String empSalary) {
		super();
		this.empId = empId;
		this.deptId = deptId;
		this.empName = empName;
		this.empSalary = empSalary;
	}
    
}
