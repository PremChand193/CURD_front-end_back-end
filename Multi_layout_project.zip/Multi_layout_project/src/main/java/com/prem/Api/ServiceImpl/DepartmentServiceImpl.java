package com.prem.Api.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prem.Api.Entity.Department;
import com.prem.Api.Repository.DepartmentRepository;
import com.prem.Api.Service.DepartmentService;

@Service
public class DepartmentServiceImpl implements DepartmentService {
	
	@Autowired
	private DepartmentRepository departmentRepo;

	@Override
	public String createDepartment(Department department) {
		     departmentRepo.save(department);
		return "Successfully created";
	}

	@Override
	public List<Department> getAllDepartments() {
		List<Department> department=departmentRepo.findAll();
		return department;
	}

	@Override
	public void updateDepartment(Department department, Integer id) {
		Department updepartment=departmentRepo.findById(id).get();
		
		updepartment.setDeptName(department.getDeptName());
		updepartment.setDeptLocation(department.getDeptLocation());
		departmentRepo.save(department);
	}

	@Override
	public Department getDepartmentById(Integer id) {
		Department department=departmentRepo.findById(id).get();
		return department;
	}

}
