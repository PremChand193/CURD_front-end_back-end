package com.prem.Api.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.prem.Api.Entity.Department;
import com.prem.Api.Entity.Message;
import com.prem.Api.Service.DepartmentService;
@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api")
public class DepartmentController {
	
	@Autowired
	private DepartmentService departmentService;
     
	@PostMapping("/department")
	public ResponseEntity<Message> createDepartment(@RequestBody Department department) {
		System.out.println("hitted");
		departmentService.createDepartment(department);
		return new ResponseEntity<>(new Message("Successfully created"),HttpStatus.CREATED);
	}
	
	@GetMapping("/department")
	public ResponseEntity<List<Department>> getAllDepartments(){
		return new ResponseEntity(departmentService.getAllDepartments(),HttpStatus.OK);
	}
	@PutMapping("/department/{id}")
	public ResponseEntity<Message> updateDepartment(@RequestBody Department department,@PathVariable Integer id){
		departmentService.updateDepartment(department,id);
		return new ResponseEntity(new Message("successfully updated"),HttpStatus.ACCEPTED);
	}
	@GetMapping("/department/{id}")
	public ResponseEntity<Department> updateDepartment(@PathVariable Integer id){
		Department department =departmentService.getDepartmentById(id);
		return new ResponseEntity(department,HttpStatus.ACCEPTED);
	}
	
	
}
