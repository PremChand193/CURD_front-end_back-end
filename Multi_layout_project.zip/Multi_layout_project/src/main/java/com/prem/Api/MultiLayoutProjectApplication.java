package com.prem.Api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiLayoutProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultiLayoutProjectApplication.class, args);
	}

}
