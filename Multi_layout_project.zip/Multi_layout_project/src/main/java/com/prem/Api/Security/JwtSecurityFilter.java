package com.prem.Api.Security;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
public class JwtSecurityFilter extends OncePerRequestFilter{
	@Autowired
	private JwtUtil jwtutil;
	@Autowired
	private CustomeUserDetails user;
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
	       String header=request.getHeader("Authorization");
	      
	       if(header!=null&&header.startsWith("Bearer ")) {
	    	   String token=header.substring(7);
	    	   System.out.println(token);
	    	   boolean valid = false;
			try {
				valid = jwtutil.validateToken(token);
			} catch (Exception e) {
			
				System.out.println(e.getMessage());
			} 	    	   
	    	   if(valid) {
	    			   String email=jwtutil.getEmailFromTokem(token);
	    			   UserDetails userDetails=user.loadUserByUsername(email);
	    		    	  UsernamePasswordAuthenticationToken authentication= 
	    		    			  new UsernamePasswordAuthenticationToken(userDetails,null,userDetails.getAuthorities());
	    		    	  SecurityContextHolder.getContext().setAuthentication(authentication);
	       	   }
	    	   else {
	    		   System.out.println("Invalid Token");
	    	   }
	       }
	       filterChain.doFilter(request, response);
	}

}
