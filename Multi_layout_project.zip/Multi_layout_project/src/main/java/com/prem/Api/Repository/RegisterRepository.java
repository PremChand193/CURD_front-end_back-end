package com.prem.Api.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prem.Api.Entity.LoginRequestBody;


public interface RegisterRepository extends JpaRepository<LoginRequestBody, Integer>{

	Optional<LoginRequestBody> findByEmail(String email);

}
