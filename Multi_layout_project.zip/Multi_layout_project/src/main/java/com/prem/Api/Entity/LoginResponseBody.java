package com.prem.Api.Entity;

import lombok.Data;
@Data
public class LoginResponseBody {

	private String token;
	private String tokenType;
	
	public LoginResponseBody() {
		super();
	}
	public LoginResponseBody(String token, String tokenType) {
		super();
		this.token = token;
		this.tokenType = tokenType;
	}
	
	
}
