package com.prem.Api.Security;

import java.util.Date;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtUtil {
	public String generateToken(Authentication authentication) {
		   String name=authentication.getName();
		   Date currentdate=new Date();
		   Date expiredate=new Date(currentdate.getTime()+1000*60*60*24);
		 String token=Jwts.builder().setSubject(name).setExpiration(expiredate).signWith(SignatureAlgorithm.HS256,"jwtCode").compact();
		return token;
	}
	public String getEmailFromTokem(String token) {
		Claims claims=Jwts.parser().setSigningKey("jwtCode").parseClaimsJws(token).getBody();
		return claims.getSubject();
	}
	public boolean validateToken(String token) throws Exception {
		try {
			Jwts.parser().setSigningKey("jwtCode").parseClaimsJws(token);	
			return true;
		}
		catch(Exception  e) {
		throw new Exception("user not found");
		}
	}
}
