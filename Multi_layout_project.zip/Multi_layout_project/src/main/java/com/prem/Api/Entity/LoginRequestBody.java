package com.prem.Api.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class LoginRequestBody {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Id;
	private String email;
	private String password;
	private String userName;
    private String phoneNumber;
	public LoginRequestBody(int id, String email, String password, String userName, String phoneNumber) {
		super();
		Id = id;
		this.email = email;
		this.password = password;
		this.userName = userName;
		this.phoneNumber = phoneNumber;
	}
	public LoginRequestBody() {
		super();
	}
    
}
