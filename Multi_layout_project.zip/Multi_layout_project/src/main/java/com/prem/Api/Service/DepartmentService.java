package com.prem.Api.Service;

import java.util.List;


import com.prem.Api.Entity.Department;

public interface DepartmentService {

	public String createDepartment(Department department);

	public List<Department>getAllDepartments();

	public void updateDepartment(Department department, Integer id);

	public Department getDepartmentById(Integer id);	
	
}
