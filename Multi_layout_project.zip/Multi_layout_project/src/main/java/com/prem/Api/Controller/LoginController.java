package com.prem.Api.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.prem.Api.Entity.LoginRequestBody;
import com.prem.Api.Entity.LoginResponseBody;
import com.prem.Api.Entity.Message;
import com.prem.Api.Security.JwtUtil;
import com.prem.Api.Service.LoginService;
@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api/auth")
public class LoginController {
	@Autowired
	private LoginService loginService;
	@Autowired
	private AuthenticationManager authenticationManager;
	@Autowired
	private JwtUtil jwtUtil;
	@PostMapping("/register")
	public ResponseEntity<Message> registerUser(@RequestBody LoginRequestBody login) {
		loginService.RegisterUser(login);
		return new ResponseEntity(new Message("successfuly Register"),HttpStatus.OK);
	}
	@PostMapping("/login")
	public ResponseEntity<LoginResponseBody> getToken(@RequestBody LoginRequestBody login){
		Authentication authentication=null;
		try
		{
		authentication=authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(login.getEmail(),login.getPassword()));
		}							
		catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println(login.toString());
		if(authentication==null) {
			return new ResponseEntity<>(new LoginResponseBody(),HttpStatus.BAD_REQUEST);
		}
		else {
			 SecurityContextHolder.getContext().setAuthentication(authentication);
			 String token=jwtUtil.generateToken(authentication);
			 System.out.println(token);
				return new ResponseEntity<>(new LoginResponseBody(token,"Bearer "),HttpStatus.OK);
		}
	}

}
