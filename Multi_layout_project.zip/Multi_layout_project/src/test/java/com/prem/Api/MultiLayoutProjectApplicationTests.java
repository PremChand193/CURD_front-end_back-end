package com.prem.Api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiLayoutProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
